 @foreach ($data as $datas)
 <span class="badge bg-primary">{{$datas->s_specimen_data_name}}</span>
 @endforeach
