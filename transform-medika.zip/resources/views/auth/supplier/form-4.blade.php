<!-- <div class="wizard-lottie-wrapper">
    <div class="lottie wizard-lottie mx-auto my-3"
        data-options='{"path":"../../../../asset/img/animated-icons/celebration.json"}'>
    </div>
</div> -->
<h4 class="mb-1">Your Purchase Order is Ready!</h4>
<p>Now you can access Purchase Order</p>
<a class="btn btn-primary px-5 my-3" href="#" onclick="location.reload();">Terima
    Kasih</a>
