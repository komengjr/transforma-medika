<div class="card mb-3">
    <div class="card-body border">
        asd
    </div>
</div>
