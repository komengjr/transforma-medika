@extends('layouts.layouts')
@section('content')
    <div class="card mb-3">
        <div class="bg-holder d-none d-lg-block bg-card"
            style="background-image:url(../../assets/img/icons/spot-illustrations/corner-4.png);">
        </div>
        <!--/.bg-holder-->

        <div class="card-body position-relative">
            <div class="row">
                <div class="col-lg-8">
                    <h3>FAQ Slip</h3>
                    <p class="mb-0">Below you'll find answers to the questions we get <br class="d-none.d-sm-block"> asked
                        the most about to join with Falcon</p>
                </div>
            </div>
        </div>
    </div>

@endsection
